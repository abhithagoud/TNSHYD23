package tns.day2;

public class B {
	int a=4;
	static int b=5;
	int display() {
		return 4;
	}
	static void display2() {
		System.out.println(4);
	}

	public static void main(String[] args) {
	int c=2;
	System.out.println(c);
	B a1=new B();
	System.out.println(a1.a);
	System.out.println(a1.display());
	B.display2();

	}

}
