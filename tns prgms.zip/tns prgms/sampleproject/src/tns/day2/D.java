package tns.day2;

public class D {
public static void main(String[] args) {
	C c1 =new C();
	System.out.println(c1.a);
	c1.A();
	System.out.println(C.b);
	System.out.println(C.B());
	
}
}
