package tns.day2;

public class C {
int a =10;
static int b =20;
void A() {
System.out.println("tns session");
}
static int B() {
	return 30;
	
}
}
