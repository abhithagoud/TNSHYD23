package com.prct1;

public class Prct1 {

	protected void display()
	{
		System.out.println("tns");
	}
	}


