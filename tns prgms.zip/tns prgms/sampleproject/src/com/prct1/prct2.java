package com.prct1;
import Prct1.*;

public class  prct2 extends Prct1 
{
public void display() {

}
public static void main(String[] args) {
	// TODO Auto-generated method stub
	Prct1 obj=new Prct1();
	obj.display();
	

}

	}


