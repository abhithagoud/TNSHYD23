package com.modifiers3;

public class Car {
public static void main(String[] args) {
	student s = new student();
	System.out.println(s.rollNo);
	s.printrollnumber();
}
}
