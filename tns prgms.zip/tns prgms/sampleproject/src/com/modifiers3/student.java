package com.modifiers3;

public class student {
	public int rollNo = 401;
	public student() {
		rollNo = 402;
		
	}

	public void printrollnumber() {
		System.out.println(rollNo);
		

	}

}
