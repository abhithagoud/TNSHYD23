package com.acceccmodifiers;

public class DefaultMain {
	public static void main(String[] args ) {
		DefaultA d1=new DefaultA();
		d1.display();
				
	}

}
