package com.gands;

public class Egbt2 {

	public static void main(String[] args) {
	Egbt1 e1 =new Egbt1();
	e1.details=student;
	System.out.println(e1.details);
		

	}

}
