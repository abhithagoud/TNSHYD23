package com.gands;

public class Egbt1 {
	
	private String age;
private String gender;
private String name;
public int details;

}
