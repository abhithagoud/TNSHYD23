package com.prvt;

public class Prvt1 {
	private void display() {
		System.out.println("tns");
	}
	public static void main(String[] args) {
		Prvt1 p=new Prvt1();
		p.display();
	}

}
