package com.methods;

public class MethodwithoutParametersNoReturnType1 {
	
	public static void main(String[] args) {
		loop();
	}
	
	public static void loop() {
		
		int i=1;
		while(i<=10) {
			System.out.println(i);
			i++;
		}
	}
	

}
