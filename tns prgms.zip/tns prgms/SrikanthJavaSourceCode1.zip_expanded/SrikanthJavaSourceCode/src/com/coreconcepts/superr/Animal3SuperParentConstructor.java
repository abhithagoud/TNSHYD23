package com.coreconcepts.superr;

public class Animal3SuperParentConstructor {
	
	Animal3SuperParentConstructor(){
		System.out.println("Animal is created");
	}
	
}
