package com.coreconcepts.interfacee;

public class Iphone8 implements Phone{

	@Override
	public String processor() {
		// TODO Auto-generated method stub
		return "A11";
	}

	@Override
	public String OS() {
		// TODO Auto-generated method stub
		return "IOS";
	}

	@Override
	public int spaceInGB() {
		// TODO Auto-generated method stub
		return 64;
	}

}
