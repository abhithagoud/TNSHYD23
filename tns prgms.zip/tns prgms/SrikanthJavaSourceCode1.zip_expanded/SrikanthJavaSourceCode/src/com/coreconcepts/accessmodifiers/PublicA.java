package com.coreconcepts.accessmodifiers;

public class PublicA {
	
	public void display() {
		System.out.println("TNS Sessions");
	}

}
