package com.oop2.inheritence;

public class HierarchialMain {
	
	public static void main(String[] args) {
		HierarchialInheritenceB b1 = new HierarchialInheritenceB();
		HierarchialInheritenceC c1 = new HierarchialInheritenceC();
		HierarchialInheritenceD d1 = new HierarchialInheritenceD();
		
		b1.display();
		c1.display();
		d1.display();
	}

}
