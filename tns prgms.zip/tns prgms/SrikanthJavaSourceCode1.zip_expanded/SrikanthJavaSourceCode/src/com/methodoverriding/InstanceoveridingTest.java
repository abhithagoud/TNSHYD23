package com.methodoverriding;

public class InstanceoveridingTest {
	
	public static void main(String[] args) {
		//Parent p1 = new Parent();
		//p1.show();
		
		Parent p2 = new Child();
		p2.show();
		
	}
	

}
